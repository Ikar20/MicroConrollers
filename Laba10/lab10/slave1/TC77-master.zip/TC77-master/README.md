TC77 Temperature Sensor library
